# Be sure to restart your server when you modify this file.

CSVImportExample::Application.config.session_store :cookie_store, key: '_CSVImportExample_session'
