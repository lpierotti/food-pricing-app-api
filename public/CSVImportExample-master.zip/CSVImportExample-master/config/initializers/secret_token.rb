# Be sure to restart your server when you modify this file.

# Your secret key is used for verifying the integrity of signed cookies.
# If you change this key, all old signed cookies will become invalid!

# Make sure the secret is at least 30 characters and all random,
# no regular words or you'll be exposed to dictionary attacks.
# You can use `rake secret` to generate a secure secret key.

# Make sure your secret_key_base is kept private
# if you're sharing your code publicly.
CSVImportExample::Application.config.secret_key_base = '855266d3515ed9d514c45794555827dbb452a8dbcadf05f8dfb3fb2c38dd98e3b5a64414a8e23a9c307536b7d292dc6e644425f0e7e40e0b3fa1b4f7a742e447'
